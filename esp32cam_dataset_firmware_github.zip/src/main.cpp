
#include <WiFi.h>
#include <ESPAsyncWebServer.h>
#include <ElegantOTA.h>
#include <FS.h>
#include <SPIFFS.h>
#include "esp_camera.h"

const char* ssid = "POST-SETUP";
const char* password = "post1234";

AsyncWebServer server(80);

void setupCamera() {
  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = 5;
  config.pin_d1 = 18;
  config.pin_d2 = 19;
  config.pin_d3 = 21;
  config.pin_d4 = 36;
  config.pin_d5 = 39;
  config.pin_d6 = 34;
  config.pin_d7 = 35;
  config.pin_xclk = 0;
  config.pin_pclk = 22;
  config.pin_vsync = 25;
  config.pin_href = 23;
  config.pin_sccb_sda = 26;
  config.pin_sccb_scl = 27;
  config.pin_pwdn = 32;
  config.pin_reset = -1;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_SVGA;
  config.jpeg_quality = 12;
  config.fb_count = 2;

  esp_camera_init(&config);
}

String captureAndSave(String label) {
  camera_fb_t* fb = esp_camera_fb_get();
  if (!fb) return "Capture failed";

  String filename = "/" + label + "_" + String(millis()) + ".jpg";
  File file = SPIFFS.open(filename.c_str(), FILE_WRITE);
  if (!file) return "File open failed";
  file.write(fb->buf, fb->len);
  file.close();
  esp_camera_fb_return(fb);
  return "Saved: " + filename;
}

void setup() {
  Serial.begin(115200);
  setupCamera();
  SPIFFS.begin(true);
  WiFi.softAP(ssid, password);
  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/html",
      "<h2>ESP32 Postbox Dataset Capture</h2>"
      "<p><a href='/capture?label=post'>📬 Bild mit Post</a></p>"
      "<p><a href='/capture?label=leer'>📭 Bild ohne Post</a></p>"
      "<p><a href='/list'>📁 Bilder anzeigen</a></p>"
    );
  });

  server.on("/capture", HTTP_GET, [](AsyncWebServerRequest *request){
    if (!request->hasParam("label")) {
      request->send(400, "text/plain", "Missing label");
      return;
    }
    String label = request->getParam("label")->value();
    String result = captureAndSave(label);
    request->send(200, "text/plain", result);
  });

  server.on("/list", HTTP_GET, [](AsyncWebServerRequest *request){
    String output = "<h3>SPIFFS Inhalt:</h3><ul>";
    File root = SPIFFS.open("/");
    File file = root.openNextFile();
    while (file) {
      output += "<li><a href='/" + String(file.name()) + "'>" + String(file.name()) + "</a></li>";
      file = root.openNextFile();
    }
    output += "</ul>";
    request->send(200, "text/html", output);
  });

  ElegantOTA.begin(&server);
  server.begin();
}

void loop() {
  ElegantOTA.loop();
}
